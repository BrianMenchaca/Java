package edu.unlam.taller.observer;

public abstract class Observador {

	public abstract void notificarse();
	
}
