package edu.unlam.taller.state;

import edu.unlam.taller.elementos.Bloque;

public class MarioMuerto extends EstadoMario {

	@Override
	public void golpearBloque(Bloque bloque) { }

}
