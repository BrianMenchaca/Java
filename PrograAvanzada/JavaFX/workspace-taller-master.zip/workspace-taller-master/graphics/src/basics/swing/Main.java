package basics.swing;

public class Main {
	public static void main(String[] args) {
		new Frame();
	}
}
