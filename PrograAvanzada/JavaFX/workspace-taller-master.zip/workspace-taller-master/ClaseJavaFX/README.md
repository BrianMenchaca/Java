# JavaFX en Maven

## Cómo ejecutarlo

1. Click Derecho en el proyecto
2. Run As...
3. maven build
4. en Goals, especificar `javafx:run`
5. Luego de descargar las bibliotecas, debería comenzar la ejecución

> Nota: Probablemente haya que configurar las propiedades del proyecto para establecer la versión de compilación en 1.8 o superior.
