# Workspace del Taller de Programación Avanzada

[![Codacy Badge](https://api.codacy.com/project/badge/Grade/b5ae03bcb80f4719807b60c95087d41a)](https://app.codacy.com/gh/programacion-avanzada/workspace-taller?utm_source=github.com&utm_medium=referral&utm_content=programacion-avanzada/workspace-taller&utm_campaign=Badge_Grade_Dashboard)

Este repositorio es canónico, y posee los ejemplos dados habitualmente para los temas dictados.
Si bien es un workspace de Eclipse, puede utilizarse con otras herramientas e IDEs.

## Colaborar con este repositorio

Si tuvieras una idea interesante que quisieras compartir, podrías utilizar el mecanismo de Pull Requests de GitHub para colaborar y sumar tu aporte a la materia. ¡Nos encanta recibir aportes!

También podés abrir un Issue para que lo revisemos si encontrás algo que cambiar o mejorar.

