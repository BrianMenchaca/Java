package flappy_bird.utils;

public abstract class GameObject {
	public abstract void destroy();
}
