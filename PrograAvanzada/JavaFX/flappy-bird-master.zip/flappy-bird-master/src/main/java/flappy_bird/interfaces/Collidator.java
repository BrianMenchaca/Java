package flappy_bird.interfaces;

public interface Collidator extends Collideable {
	public void collide(Collideable collideable);
}
