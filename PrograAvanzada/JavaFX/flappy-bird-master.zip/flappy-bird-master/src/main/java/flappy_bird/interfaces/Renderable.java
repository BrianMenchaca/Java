package flappy_bird.interfaces;

import javafx.scene.Node;

public interface Renderable {
	public Node getRender();
}
