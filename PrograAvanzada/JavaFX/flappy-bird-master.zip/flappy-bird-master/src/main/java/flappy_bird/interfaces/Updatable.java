package flappy_bird.interfaces;

public interface Updatable {
	public void update(double deltaTime);
}
