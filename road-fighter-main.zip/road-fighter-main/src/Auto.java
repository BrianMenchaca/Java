package roadFighter;

public class Auto {

	public void frenar() {
		// TODO Auto-generated method stub
		
	}

	public void moverseHorizontal(double random) {
		// TODO Auto-generated method stub
		
	}

}
