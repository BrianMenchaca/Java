package MenuPrincipal;


public class Menu {


	public void mostrarMenu() {
	}

	public void ocultarMenu() {
	}

	public void iniciarSesion() {
	}

	public void ajustarVolumen() {
	}
	

}
