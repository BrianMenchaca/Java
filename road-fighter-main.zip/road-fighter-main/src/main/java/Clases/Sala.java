package Clases;
import java.util.List;

public class Sala {
	private List<Usuario> usuarios;

	public Sala(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}


	public void iniciarPartida(Usuario admin, List<Usuario> usuarios) {
	}
}
